

from collections import deque


class Queue:
    pass
