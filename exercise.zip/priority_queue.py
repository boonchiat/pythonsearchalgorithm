

import heapq


class PriorityQueue:
    pass
