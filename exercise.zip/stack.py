


class Stack:
    pass
